$.ajax({
    type: 'get',
    url: '/posts',
    success: function (res) {
        console.log(res);
        var html = template('postsTpl', res);
        $('#postsBox').html(html)
        var page = template('pageTpl', res);
        $('.pagination').html(page);
    }
})

//定义一个格式化时间的函数
function dateFormat(date) {
    date = new Date(date)
    return date.getFullYear() + '年' + (date.getMonth() + 1) + '月' + date.getDate() + '日';
}

// 渲染出来的用事件委托写
// 直接用行内样式